def run(items, idfun=None):
    if idfun is None:
        def idfun(x): return x
    seen = {}
    result = []
    for item in items:
        marker = idfun(item)
        if marker in seen: continue
        seen[marker] = 1
        result.append(item)
    return result


